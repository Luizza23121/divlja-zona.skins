<?php
define('SKIN_LANGUAGE', 'skins_en');

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', '');
define('DB_USER', '');
define('DB_PASS', '');

define('WEB_STYLE_DARK', true);

define('STEAM_API_KEY', '');
define('STEAM_DOMAIN_NAME', '');
define('STEAM_LOGOUT_PAGE', '');
define('STEAM_LOGIN_PAGE', '');

